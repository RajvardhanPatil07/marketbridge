# Push the MarketBridge v0.3 AI upgrade

This package is intended to be overlaid on the current `RajvardhanPatil07/marketbridge` repository.

## What it adds

- Learned fair-value inference with Ridge vs Gradient-Boosted Stump model selection.
- Separate learned venue-mark anomaly probability.
- Direct-consensus-first safety boundary: AI never creates `QUALIFIED` evidence.
- AI can only tighten deterministic risk after non-synthetic calibration.
- QQQ/SPY/SOXX factor tracking in the live Alpaca pipeline.
- Model provenance and evaluation API endpoints.
- AI explainability panel in the live dashboard.
- Offline historical/research dataset builder and retraining pipeline.
- Tests for model loading, learned fallback, consensus precedence and anomaly behavior.

## Recommended Codex/Git flow

```bash
git clone https://github.com/RajvardhanPatil07/marketbridge.git
cd marketbridge
git checkout -b feat/ai-fair-value-risk-v0.3
```

Overlay the files from `MarketBridge-v0.3-AI-changed-files.zip` into the repository root, or apply the patch:

```bash
git apply MarketBridge-v0.3-AI.patch
```

Then verify:

```bash
uv sync --frozen
npm --prefix apps/web ci
uv run pytest -q
npm --prefix apps/web run typecheck
```

Optional historical/research training (requires internet access):

```bash
make build-ml-dataset
uv run python scripts/train_ai_models.py \
  --csv data/ml_training.csv \
  --data-mode HISTORICAL_RESEARCH
```

Commit and push:

```bash
git add -A
git commit -m "feat: add AI fair-value and anomaly risk layer"
git push -u origin feat/ai-fair-value-risk-v0.3
```

Open a PR:

```bash
gh pr create \
  --repo RajvardhanPatil07/marketbridge \
  --base main \
  --head feat/ai-fair-value-risk-v0.3 \
  --title "feat: add AI fair-value and anomaly risk layer" \
  --body "Adds learned fair-value fallback, anomaly probability, model provenance, historical retraining tooling, explainability UI, and tests while preserving deterministic evidence and risk controls."
```

## Claim boundary

The checked-in model is labelled `SYNTHETIC_CALIBRATION_DEMO`. Do not quote its MAE as historical/live performance. Retrain with the historical research dataset and quote only the resulting held-out metrics.
