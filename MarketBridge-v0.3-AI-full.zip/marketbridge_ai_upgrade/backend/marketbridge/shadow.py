"""Low-latency shadow-oracle pipeline with deterministic safety + learned estimates.

Direct independent market evidence always has priority. A learned fair-value model
may provide a lower-trust ESTIMATED reference when direct evidence is insufficient.
Anomaly probability is advisory and can only tighten risk when the loaded model is
explicitly configured as non-synthetic. The venue mark never validates itself.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
from queue import SimpleQueue
from statistics import median
from threading import Condition, Event, Lock, Thread
from time import perf_counter_ns
from typing import Callable

from .live import get_live_snapshot
from .ml import MarketBridgeAI


EQUITY_SYMBOLS = ("NVDA", "TSLA", "AAPL", "MSFT", "AMD")
FACTOR_SYMBOLS = ("QQQ", "SPY", "SOXX")
TRACKED_SYMBOLS = (*EQUITY_SYMBOLS, *FACTOR_SYMBOLS)
FRESH_SECONDS = 10
AGREEMENT_BPS = 75
LARGE_MOVE_BPS = 500

# Safety fallback if no learned model bundle is available. These are explicitly
# static prototype coefficients and remain lower trust than direct consensus.
QQQ_BETA = {
    "NVDA": 1.45,
    "TSLA": 1.30,
    "AAPL": 1.05,
    "MSFT": 1.00,
    "AMD": 1.35,
}


def _utc(value: str | datetime) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    else:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _bps(price: float, anchor: float) -> float:
    if anchor <= 0:
        return 0.0
    return math.log(price / anchor) * 10_000


@dataclass(frozen=True)
class NormalizedObservation:
    symbol: str
    price: float
    event_time: datetime
    received_at: datetime
    source_id: str
    source_family: str
    venue: str
    eligible: bool
    provider_family: str | None = None
    venue_family: str | None = None

    @property
    def provider(self) -> str:
        if self.provider_family:
            return self.provider_family
        if self.source_id.startswith("alpaca"):
            return "alpaca"
        if self.source_id.startswith("hyperliquid"):
            return "hyperliquid"
        if self.source_id.startswith("yfinance") or "yahoo" in self.source_family:
            return "yahoo"
        return self.source_id.split(":", 1)[0]

    @property
    def venue_key(self) -> str:
        return self.venue_family or self.venue or self.source_family


class ShadowOracle:
    """Normalize evidence and produce an advisory reference/risk decision."""

    def __init__(
        self,
        audit_sink: Callable[[dict], None] | None = None,
        ai: MarketBridgeAI | None = None,
    ):
        self._latest: dict[str, dict[str, NormalizedObservation]] = {}
        self._marks: dict[str, dict] = {}
        self._last_reference: dict[str, float] = {}
        self._anchor_time: dict[str, datetime] = {}
        self._factor_reference: dict[str, float] = {}
        self._stock_factor_anchor: dict[str, dict[str, float]] = {}
        self._decisions: dict[str, dict] = {}
        self._history: deque[dict] = deque(maxlen=500)
        self._latencies: deque[float] = deque(maxlen=1000)
        self._source_age_ms: deque[float] = deque(maxlen=1000)
        self._generation = 0
        self._lock = Lock()
        self._changed = Condition(self._lock)
        self._audit_sink = audit_sink
        self.ai = ai or MarketBridgeAI.from_environment()

    def ai_status(self) -> dict:
        status = self.ai.status()
        status["risk_signal_enforced"] = bool(
            status.get("enabled") and not str(status.get("data_mode") or "").startswith("SYNTHETIC")
        )
        return status

    def ingest(self, observation: NormalizedObservation) -> dict:
        if observation.symbol not in TRACKED_SYMBOLS:
            raise ValueError(f"unsupported symbol: {observation.symbol}")
        if not math.isfinite(observation.price) or observation.price <= 0:
            raise ValueError("observation price must be positive and finite")
        started = perf_counter_ns()
        source_age_ms = max(0.0, (observation.received_at - observation.event_time).total_seconds() * 1000)
        key = f"{observation.provider}|{observation.venue_key}|{observation.source_id}"
        with self._changed:
            self._latest.setdefault(observation.symbol, {})[key] = observation
            decision = self._decide(observation.symbol, observation.received_at)
            decision["decision_latency_ms"] = (perf_counter_ns() - started) / 1_000_000
            decision["provider_to_decision_ms"] = source_age_ms
            decision["source_event_age_ms"] = source_age_ms
            self._latencies.append(decision["decision_latency_ms"])
            self._source_age_ms.append(source_age_ms)
            self._decisions[observation.symbol] = decision
            if observation.symbol in EQUITY_SYMBOLS:
                self._history.appendleft(decision)
            self._generation += 1
            self._changed.notify_all()
        if self._audit_sink and observation.symbol in EQUITY_SYMBOLS:
            self._audit_sink(decision)
        return decision

    def update_venue_mark(self, symbol: str, price: float, event_time: datetime) -> dict:
        if symbol not in EQUITY_SYMBOLS:
            raise ValueError(f"unsupported venue-mark symbol: {symbol}")
        if not math.isfinite(price) or price <= 0:
            raise ValueError("mark price must be positive and finite")
        started = perf_counter_ns()
        audited_decision = None
        with self._changed:
            mark = {
                "price": price,
                "event_time": event_time.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            }
            self._marks[symbol] = mark
            current = self._decisions.get(symbol)
            if current:
                reasons = [reason for reason in current["reasons"] if reason != "VENUE_MARK_OBSERVED"]
                reference = current["reference"]
                divergence = abs(price / reference - 1) * 10_000 if reference else None
                anomaly_probability, anomaly_factors = self._anomaly_score(
                    current.get("evidence", []), current["status"], divergence
                )
                ai_payload = dict(current.get("ai") or self._empty_ai_payload())
                ai_payload["anomaly_probability"] = anomaly_probability
                ai_payload["anomaly_factors"] = anomaly_factors
                enforce_ai = self._ai_risk_enforced(ai_payload)
                risk = self._risk_policy(
                    current.get("confidence", 0),
                    divergence,
                    current["status"],
                    anomaly_probability,
                    enforce_ai,
                )
                if anomaly_probability is not None and anomaly_probability >= 0.90:
                    reasons.append("AI_ANOMALY_SIGNAL_HIGH")
                audited_decision = {
                    **current,
                    "decision_id": f"{symbol}-{self._generation + 1}",
                    "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                    "reasons": list(dict.fromkeys([*reasons, "VENUE_MARK_OBSERVED"])),
                    "venue_mark": mark,
                    "mark_divergence_bps": divergence,
                    "decision_latency_ms": (perf_counter_ns() - started) / 1_000_000,
                    "ai": ai_payload,
                    **risk,
                }
                self._latencies.append(audited_decision["decision_latency_ms"])
                self._decisions[symbol] = audited_decision
                self._history.appendleft(audited_decision)
            self._generation += 1
            self._changed.notify_all()
        if self._audit_sink and audited_decision:
            self._audit_sink(audited_decision)
        return mark

    def _eligible_evidence(self, symbol: str, now: datetime) -> tuple[list[dict], list[NormalizedObservation]]:
        evidence: list[dict] = []
        eligible: list[NormalizedObservation] = []
        for source in self._latest.get(symbol, {}).values():
            age = max(0.0, (now - source.event_time).total_seconds())
            row = {
                "source_id": source.source_id,
                "family": source.source_family,
                "provider_family": source.provider,
                "venue_family": source.venue_key,
                "venue": source.venue,
                "price": source.price,
                "event_time": source.event_time.isoformat().replace("+00:00", "Z"),
                "age_seconds": age,
                "eligible": source.eligible,
                "fresh": age <= FRESH_SECONDS,
            }
            evidence.append(row)
            if row["eligible"] and row["fresh"]:
                eligible.append(source)
        return evidence, eligible

    @staticmethod
    def _independence(eligible: list[NormalizedObservation]) -> tuple[int, int]:
        providers = {item.provider for item in eligible}
        venues = {item.venue_key for item in eligible}
        return len(providers), len(venues)

    @staticmethod
    def _dispersion_bps(eligible: list[NormalizedObservation]) -> float:
        prices = [source.price for source in eligible]
        if len(prices) < 2:
            return 0.0
        return (max(prices) / min(prices) - 1) * 10_000

    def _fresh_factor_price(self, factor: str, now: datetime) -> float | None:
        rows = [
            source
            for source in self._latest.get(factor, {}).values()
            if source.eligible and max(0.0, (now - source.event_time).total_seconds()) <= FRESH_SECONDS
        ]
        return median([row.price for row in rows]) if rows else None

    def _factor_features(
        self,
        symbol: str,
        now: datetime,
        stock_eligible: list[NormalizedObservation],
    ) -> dict[str, float] | None:
        stock_anchor = self._last_reference.get(symbol)
        if stock_anchor is None:
            return None
        anchors = self._stock_factor_anchor.setdefault(symbol, {})
        factor_returns: dict[str, float] = {}
        at_least_one_factor = False
        for factor in FACTOR_SYMBOLS:
            current = self._fresh_factor_price(factor, now)
            if current is None:
                factor_returns[factor] = 0.0
                continue
            at_least_one_factor = True
            if factor not in anchors:
                anchors[factor] = current
            factor_returns[factor] = _bps(current, anchors[factor])
        if not at_least_one_factor:
            return None

        stock_prices = [row.price for row in stock_eligible]
        single_source_return = _bps(median(stock_prices), stock_anchor) if stock_prices else 0.0
        ages = [max(0.0, (now - row.event_time).total_seconds()) * 1000 for row in stock_eligible]
        source_age_ms = median(ages) if ages else float(FRESH_SECONDS * 1000)
        providers, venues = self._independence(stock_eligible)
        anchor_time = self._anchor_time.get(symbol, now)
        minutes_since_anchor = max(0.0, (now - anchor_time).total_seconds() / 60.0)
        return {
            "qqq_return_bps": factor_returns.get("QQQ", 0.0),
            "spy_return_bps": factor_returns.get("SPY", 0.0),
            "soxx_return_bps": factor_returns.get("SOXX", 0.0),
            "single_source_return_bps": single_source_return,
            "minutes_since_anchor": minutes_since_anchor,
            "source_age_ms": source_age_ms,
            "provider_count": float(providers),
            "venue_count": float(venues),
        }

    def _learned_estimate(
        self,
        symbol: str,
        now: datetime,
        stock_eligible: list[NormalizedObservation],
    ) -> tuple[object | None, dict[str, float] | None]:
        if symbol not in EQUITY_SYMBOLS:
            return None, None
        features = self._factor_features(symbol, now, stock_eligible)
        stock_anchor = self._last_reference.get(symbol)
        if features is None or stock_anchor is None:
            return None, features
        return self.ai.predict_fair_value(symbol, stock_anchor, features), features

    def _static_factor_estimate(self, symbol: str, now: datetime) -> tuple[float | None, float, list[str]]:
        if symbol not in QQQ_BETA:
            return None, 0.0, []
        qqq_price = self._fresh_factor_price("QQQ", now)
        stock_anchor = self._last_reference.get(symbol)
        if qqq_price is None or stock_anchor is None:
            return None, 0.0, []
        anchors = self._stock_factor_anchor.setdefault(symbol, {})
        qqq_anchor = anchors.setdefault("QQQ", qqq_price)
        qqq_return = qqq_price / qqq_anchor - 1
        estimate = stock_anchor * math.exp(QQQ_BETA[symbol] * math.log1p(qqq_return))
        qqq_rows = [
            source
            for source in self._latest.get("QQQ", {}).values()
            if source.eligible and max(0.0, (now - source.event_time).total_seconds()) <= FRESH_SECONDS
        ]
        providers, venues = self._independence(qqq_rows)
        confidence = min(62.0, 42.0 + providers * 6.0 + venues * 3.0)
        return estimate, confidence, ["QQQ_STATIC_FACTOR_FALLBACK", "ESTIMATE_NOT_DIRECT_MARKET_EVIDENCE"]

    def _empty_ai_payload(self) -> dict:
        status = self.ai_status()
        return {
            "enabled": status["enabled"],
            "model_version": status["model_version"],
            "data_mode": status["data_mode"],
            "fair_value_used": False,
            "fair_value_model_type": None,
            "predicted_reference": None,
            "predicted_return_bps": None,
            "top_factors": [],
            "anomaly_probability": None,
            "anomaly_factors": [],
            "risk_signal_enforced": status["risk_signal_enforced"],
        }

    @staticmethod
    def _ai_risk_enforced(ai_payload: dict) -> bool:
        return bool(ai_payload.get("risk_signal_enforced"))

    def _anomaly_score(
        self,
        evidence: list[dict],
        status: str,
        divergence_bps: float | None,
    ) -> tuple[float | None, list[dict]]:
        fresh_eligible = [row for row in evidence if row.get("fresh") and row.get("eligible")]
        prices = [float(row["price"]) for row in fresh_eligible]
        dispersion = (max(prices) / min(prices) - 1) * 10_000 if len(prices) >= 2 else 0.0
        ages = [float(row.get("age_seconds") or 0.0) * 1000 for row in fresh_eligible]
        providers = len({row.get("provider_family") for row in fresh_eligible})
        venues = len({row.get("venue_family") for row in fresh_eligible})
        features = {
            "mark_divergence_bps": float(divergence_bps or 0.0),
            "dispersion_bps": dispersion,
            "source_age_ms": median(ages) if ages else float(FRESH_SECONDS * 1000),
            "provider_count": float(providers),
            "venue_count": float(venues),
            "status_estimated": 1.0 if status == "ESTIMATED" else 0.0,
        }
        return self.ai.anomaly_probability(features)

    @staticmethod
    def _risk_policy(
        confidence: float,
        divergence_bps: float | None,
        status: str,
        anomaly_probability: float | None = None,
        enforce_ai: bool = False,
    ) -> dict:
        divergence = divergence_bps or 0.0
        if divergence >= 500 or confidence < 35:
            state, lev, notional = "HALTED", 0, 0.0
        elif divergence >= 150 or confidence < 60:
            state, lev, notional = "RESTRICTED", 3, 0.25
        elif divergence >= 75 or confidence < 80 or status == "ESTIMATED":
            state, lev, notional = "GUARDED", 5 if status == "ESTIMATED" else 10, 0.5
        else:
            state, lev, notional = "NORMAL", 20, 1.0

        # Learned signals are permitted to tighten, never loosen, deterministic risk.
        if enforce_ai and anomaly_probability is not None:
            if anomaly_probability >= 0.95 and state == "NORMAL":
                state, lev, notional = "RESTRICTED", 3, 0.25
            elif anomaly_probability >= 0.95 and state == "GUARDED":
                state, lev, notional = "RESTRICTED", min(lev, 3), min(notional, 0.25)
            elif anomaly_probability >= 0.80 and state == "NORMAL":
                state, lev, notional = "GUARDED", 10, 0.5
        return {
            "risk_state": state,
            "recommended_max_leverage": lev,
            "max_notional_multiplier": notional,
            "new_exposure_allowed": state not in {"HALTED"},
            "advisory_exposure_multiplier": notional,
        }

    def _decide(self, symbol: str, now: datetime) -> dict:
        evidence, eligible = self._eligible_evidence(symbol, now)
        reference = None
        reasons: list[str] = []
        status = "INSUFFICIENT_EVIDENCE"
        confidence = 20.0
        band_bps = 250.0
        provider_count, venue_count = self._independence(eligible)
        dispersion_bps = self._dispersion_bps(eligible)

        prices = [source.price for source in eligible]
        qualified_candidate = None
        if venue_count >= 2 and len(prices) >= 2:
            candidate = median(prices)
            previous = self._last_reference.get(symbol)
            move_bps = 0.0 if previous is None else abs(candidate / previous - 1) * 10_000
            if dispersion_bps > AGREEMENT_BPS:
                reasons.append("CROSS_VENUE_DISAGREEMENT")
            elif previous is not None and move_bps > LARGE_MOVE_BPS and venue_count < 3:
                reasons.append("LARGE_MOVE_NEEDS_THREE_VENUE_FAMILIES")
            else:
                reference = candidate
                qualified_candidate = candidate
                status = "QUALIFIED"
                confidence = max(80.0, min(99.0, 97.0 - dispersion_bps / 10 - max(0, 2 - provider_count) * 6))
                band_bps = max(12.0, min(75.0, 12.0 + dispersion_bps * 0.6))
                reasons.append("INDEPENDENT_VENUES_AGREE")
                if provider_count < 2:
                    reasons.append("SINGLE_PROVIDER_CONCENTRATION")
        else:
            reasons.append("NEEDS_TWO_FRESH_ORIGINAL_VENUE_FAMILIES")

        ai_payload = self._empty_ai_payload()
        learned, _features = self._learned_estimate(symbol, now, eligible)
        if learned is not None:
            ai_payload.update({
                "fair_value_model_type": learned.model_type,
                "predicted_reference": learned.predicted_reference,
                "predicted_return_bps": learned.predicted_return_bps,
                "top_factors": learned.top_factors,
            })
            if reference is None:
                reference = learned.predicted_reference
                status = "ESTIMATED"
                confidence = learned.confidence
                band_bps = learned.band_bps
                ai_payload["fair_value_used"] = True
                reasons.extend(["ML_FAIR_VALUE_FALLBACK", "ESTIMATE_NOT_DIRECT_MARKET_EVIDENCE"])
                if str(learned.data_mode).startswith("SYNTHETIC"):
                    reasons.append("AI_MODEL_SYNTHETIC_CALIBRATION")

        if reference is None and symbol in EQUITY_SYMBOLS:
            estimate, factor_confidence, factor_reasons = self._static_factor_estimate(symbol, now)
            if estimate is not None:
                reference = estimate
                status = "ESTIMATED"
                confidence = factor_confidence
                band_bps = 180.0
                reasons.extend(factor_reasons)

        # Anchor only after direct evidence has qualified. Learned estimates never
        # become trusted anchors on their own.
        if qualified_candidate is not None:
            self._last_reference[symbol] = qualified_candidate
            self._anchor_time[symbol] = now
            if symbol in FACTOR_SYMBOLS:
                self._factor_reference[symbol] = qualified_candidate
            elif symbol in EQUITY_SYMBOLS:
                self._stock_factor_anchor[symbol] = dict(self._factor_reference)

        if any(not row["eligible"] for row in evidence):
            reasons.append("RESEARCH_FEED_VISIBLE_NOT_COUNTED")
        mark = self._marks.get(symbol)
        divergence_bps = abs(mark["price"] / reference - 1) * 10_000 if mark and reference else None
        anomaly_probability, anomaly_factors = self._anomaly_score(evidence, status, divergence_bps)
        ai_payload["anomaly_probability"] = anomaly_probability
        ai_payload["anomaly_factors"] = anomaly_factors
        if anomaly_probability is not None and anomaly_probability >= 0.90:
            reasons.append("AI_ANOMALY_SIGNAL_HIGH")
        risk = self._risk_policy(
            confidence,
            divergence_bps,
            status,
            anomaly_probability,
            self._ai_risk_enforced(ai_payload),
        )

        return {
            "decision_id": f"{symbol}-{self._generation + 1}",
            "timestamp": now.isoformat().replace("+00:00", "Z"),
            "symbol": symbol,
            "status": status,
            "reference": reference,
            "last_valid": self._last_reference.get(symbol),
            "confidence": round(confidence, 1),
            "band_bps": round(band_bps, 1),
            "band_lower": reference * (1 - band_bps / 10_000) if reference else None,
            "band_upper": reference * (1 + band_bps / 10_000) if reference else None,
            "independent_source_families": venue_count,
            "independent_provider_families": provider_count,
            "reasons": list(dict.fromkeys(reasons)),
            "evidence": sorted(evidence, key=lambda row: (row["provider_family"], row["venue_family"])),
            "venue_mark": mark,
            "mark_divergence_bps": divergence_bps,
            "model_version": "marketbridge-shadow-v0.3",
            "ai": ai_payload,
            **risk,
        }

    def snapshot(self) -> dict:
        with self._lock:
            ordered = sorted(self._latencies)
            source_ages = sorted(self._source_age_ms)
            p50 = median(ordered) if ordered else None
            p95 = ordered[round((len(ordered) - 1) * 0.95)] if ordered else None
            p99 = ordered[round((len(ordered) - 1) * 0.99)] if ordered else None
            age_p95 = source_ages[round((len(source_ages) - 1) * 0.95)] if source_ages else None
            return {
                "generation": self._generation,
                "decisions": [self._decisions[symbol] for symbol in EQUITY_SYMBOLS if symbol in self._decisions],
                "decision_log": list(self._history)[:60],
                "latency": {
                    "samples": len(ordered),
                    "p50_ms": p50,
                    "p95_ms": p95,
                    "p99_ms": p99,
                    "last_ms": self._history[0]["decision_latency_ms"] if self._history else None,
                    "source_event_age_p95_ms": age_p95,
                    "ui_delivery_target_ms": 250,
                },
                "ai": self.ai_status(),
            }

    def wait_for_generation(self, generation: int, timeout: float = 10.0) -> dict:
        with self._changed:
            if self._generation == generation:
                self._changed.wait(timeout=timeout)
        return self.snapshot()


class LivePipeline:
    """Own provider adapters, audit persistence and the shadow-oracle lifecycle."""

    def __init__(self, audit_path: Path):
        self._stop = Event()
        self._threads: list[Thread] = []
        self._audit_queue: SimpleQueue[dict | None] = SimpleQueue()
        self._audit_path = audit_path
        self.oracle = ShadowOracle(self._audit_queue.put)
        self._provider_status = {
            "yahoo": {"status": "STARTING", "kind": "RESEARCH", "detail": "Background bootstrap"},
            "alpaca": {
                "status": "DISABLED",
                "kind": "DIRECT_MARKET",
                "detail": "Set ALPACA_API_KEY and ALPACA_SECRET_KEY",
            },
            "hyperliquid": {
                "status": "DISABLED",
                "kind": "VENUE_MARK",
                "detail": "Set HYPERLIQUID_COIN_MAP to observe venue marks",
            },
            "mochatrade": {"status": "WAITING", "kind": "VENUE_MARK", "detail": "No mark received"},
        }
        self._yahoo: dict | None = None
        self._last_yahoo_event: dict[str, str] = {}
        self._started = False
        self._state_lock = Lock()

    def start(self) -> None:
        if self._started:
            return
        self._started = True
        self._stop.clear()
        self._threads = [
            Thread(target=self._audit_loop, name="marketbridge-audit", daemon=True),
            Thread(target=self._yahoo_loop, name="marketbridge-yahoo", daemon=True),
        ]
        if os.environ.get("ALPACA_API_KEY") and os.environ.get("ALPACA_SECRET_KEY"):
            self._provider_status["alpaca"] = {
                "status": "CONNECTING",
                "kind": "DIRECT_MARKET",
                "detail": "Alpaca WebSocket",
            }
            self._threads.append(Thread(target=self._alpaca_loop, name="marketbridge-alpaca", daemon=True))
        if os.environ.get("HYPERLIQUID_COIN_MAP"):
            self._provider_status["hyperliquid"] = {
                "status": "CONNECTING",
                "kind": "VENUE_MARK",
                "detail": "Hyperliquid WebSocket",
            }
            self._threads.append(Thread(target=self._hyperliquid_loop, name="marketbridge-hyperliquid", daemon=True))
        for thread in self._threads:
            thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._audit_queue.put(None)
        for thread in self._threads:
            thread.join(timeout=2)
        self._started = False

    def _audit_loop(self) -> None:
        self._audit_path.parent.mkdir(parents=True, exist_ok=True)
        with self._audit_path.open("a", encoding="utf-8") as output:
            while True:
                item = self._audit_queue.get()
                if item is None:
                    return
                output.write(json.dumps(item, allow_nan=False, separators=(",", ":")) + "\n")
                output.flush()

    def _yahoo_loop(self) -> None:
        while not self._stop.is_set():
            try:
                self.refresh_yahoo()
            except Exception as exc:
                with self._state_lock:
                    self._provider_status["yahoo"] = {
                        "status": "UNAVAILABLE",
                        "kind": "RESEARCH",
                        "detail": str(exc)[:160],
                    }
            self._stop.wait(15)

    def refresh_yahoo(self) -> dict:
        snapshot = get_live_snapshot(force=True)
        with self._state_lock:
            self._yahoo = snapshot
            self._provider_status["yahoo"] = {
                "status": snapshot["provider_status"],
                "kind": "RESEARCH",
                "detail": snapshot["fetched_at"],
            }
        received_at = datetime.now(timezone.utc)
        for row in snapshot["observations"]:
            if row["symbol"] not in TRACKED_SYMBOLS:
                continue
            if self._last_yahoo_event.get(row["symbol"]) == row["event_time"]:
                continue
            self._last_yahoo_event[row["symbol"]] = row["event_time"]
            self.oracle.ingest(
                NormalizedObservation(
                    symbol=row["symbol"],
                    price=row["observed_price"],
                    event_time=_utc(row["event_time"]),
                    received_at=received_at,
                    source_id="yfinance",
                    source_family="yahoo-research-feed",
                    venue=row["exchange"],
                    eligible=False,
                    provider_family="yahoo",
                    venue_family=row["exchange"],
                )
            )
        return self.snapshot()

    def _alpaca_loop(self) -> None:
        from websockets.sync.client import connect

        feed = os.environ.get("ALPACA_FEED", "iex")
        url = f"wss://stream.data.alpaca.markets/v2/{feed}"
        backoff = 1
        while not self._stop.is_set():
            try:
                with connect(url, open_timeout=8, close_timeout=2) as socket:
                    socket.send(
                        json.dumps(
                            {
                                "action": "auth",
                                "key": os.environ["ALPACA_API_KEY"],
                                "secret": os.environ["ALPACA_SECRET_KEY"],
                            }
                        )
                    )
                    socket.send(json.dumps({"action": "subscribe", "trades": list(TRACKED_SYMBOLS)}))
                    with self._state_lock:
                        self._provider_status["alpaca"] = {
                            "status": "AVAILABLE",
                            "kind": "DIRECT_MARKET",
                            "detail": f"{feed} WebSocket",
                        }
                    backoff = 1
                    for message in socket:
                        if self._stop.is_set():
                            return
                        received_at = datetime.now(timezone.utc)
                        for event in json.loads(message):
                            if event.get("T") != "t" or event.get("S") not in TRACKED_SYMBOLS:
                                continue
                            venue = str(event.get("x") or "UNKNOWN")
                            self.oracle.ingest(
                                NormalizedObservation(
                                    symbol=event["S"],
                                    price=float(event["p"]),
                                    event_time=_utc(event["t"]),
                                    received_at=received_at,
                                    source_id=f"alpaca-{feed}",
                                    source_family=f"equity-venue:{venue}",
                                    venue=venue,
                                    eligible=venue != "UNKNOWN",
                                    provider_family="alpaca",
                                    venue_family=venue,
                                )
                            )
            except Exception as exc:
                with self._state_lock:
                    self._provider_status["alpaca"] = {
                        "status": "RECONNECTING",
                        "kind": "DIRECT_MARKET",
                        "detail": str(exc)[:160],
                    }
                self._stop.wait(backoff)
                backoff = min(15, backoff * 2)

    def _hyperliquid_loop(self) -> None:
        """Observe configured Hyperliquid asset contexts as venue marks."""
        from websockets.sync.client import connect

        coin_map = json.loads(os.environ["HYPERLIQUID_COIN_MAP"])
        reverse = {coin: symbol for symbol, coin in coin_map.items() if symbol in EQUITY_SYMBOLS}
        backoff = 1
        while not self._stop.is_set():
            try:
                with connect("wss://api.hyperliquid.xyz/ws", open_timeout=8, close_timeout=2) as socket:
                    for coin in reverse:
                        socket.send(
                            json.dumps(
                                {"method": "subscribe", "subscription": {"type": "activeAssetCtx", "coin": coin}}
                            )
                        )
                    with self._state_lock:
                        self._provider_status["hyperliquid"] = {
                            "status": "AVAILABLE",
                            "kind": "VENUE_MARK",
                            "detail": f"{len(reverse)} configured assets",
                        }
                    backoff = 1
                    for message in socket:
                        if self._stop.is_set():
                            return
                        payload = json.loads(message)
                        if payload.get("channel") != "activeAssetCtx":
                            continue
                        data = payload.get("data") or {}
                        coin = data.get("coin")
                        ctx = data.get("ctx") or {}
                        symbol = reverse.get(coin)
                        mark = ctx.get("markPx")
                        if symbol and mark:
                            self.ingest_mochatrade(
                                symbol,
                                float(mark),
                                datetime.now(timezone.utc),
                                source="hyperliquid",
                            )
            except Exception as exc:
                with self._state_lock:
                    self._provider_status["hyperliquid"] = {
                        "status": "RECONNECTING",
                        "kind": "VENUE_MARK",
                        "detail": str(exc)[:160],
                    }
                self._stop.wait(backoff)
                backoff = min(15, backoff * 2)

    def ingest_mochatrade(
        self,
        symbol: str,
        mark_price: float,
        event_time: datetime,
        source: str = "mochatrade",
    ) -> dict:
        mark = self.oracle.update_venue_mark(symbol, mark_price, event_time)
        with self._state_lock:
            self._provider_status[source] = {
                "status": "AVAILABLE",
                "kind": "VENUE_MARK",
                "detail": mark["event_time"],
            }
        return mark

    def wait_for_generation(self, generation: int, timeout: float = 10.0) -> dict:
        return {
            "data_mode": "SHADOW_ORACLE",
            "advisory_only": True,
            "started": self._started,
            **self.oracle.wait_for_generation(generation, timeout),
            **self._provider_payload(),
        }

    def _provider_payload(self) -> dict:
        with self._state_lock:
            providers = [{"id": key, **value} for key, value in self._provider_status.items()]
            yahoo = self._yahoo
        return {"providers": providers, "yahoo": yahoo}

    def snapshot(self) -> dict:
        return {
            "data_mode": "SHADOW_ORACLE",
            "advisory_only": True,
            "started": self._started,
            **self._provider_payload(),
            **self.oracle.snapshot(),
        }


def test_observation(symbol: str, price: float, family: str, venue: str, now: datetime) -> NormalizedObservation:
    """Small public constructor used by tests and local integration probes."""
    return NormalizedObservation(symbol, price, now, now, family, family, venue, True)
